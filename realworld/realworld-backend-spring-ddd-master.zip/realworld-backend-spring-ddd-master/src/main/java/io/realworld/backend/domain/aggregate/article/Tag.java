package io.realworld.backend.domain.aggregate.article;

public class Tag {}
