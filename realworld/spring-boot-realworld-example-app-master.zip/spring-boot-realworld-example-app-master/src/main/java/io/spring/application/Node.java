package io.spring.application;

public interface Node {
  PageCursor getCursor();
}
